#!/bin/sh

model=`cat /var/lib/misc/model`

`echo 'at$lgtpwdn' > /dev/ttyACM0; sleep 0.1` 
sleep 5 

if [ $model == "FML50" ] 
then
    echo 70 > /sys/class/gpio/export
    sleep 1

    echo out > /sys/class/gpio/gpio70/direction
    sleep 1
else                
    echo out > /sys/class/gpio/gpio91/direction
    sleep 1                                    
fi             

sync  
reboot 
