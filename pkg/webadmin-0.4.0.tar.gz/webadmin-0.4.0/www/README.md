# ftm_manager

## /etc/httpd.conf 파일 생성

아래 로그인 정보를 넣어줍니다.
+ location: office
+ userid: admin
+ passwd: 21232f297a57a5a743894a0e4a801fc3
+ timeout: 60
