#include <stdio.h> /* Standard input/output definitions */
#include <string.h> /* String function definitions */
#include <unistd.h> /* UNIX standard function definitions */
#include <fcntl.h> /* File control definitions */
#include <errno.h> /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include "qdecoder.h"

int IOT_NETWORK_STATE(qentry_t *pReq) 
{
		// Parse queries.
		qentry_t *req = qcgireq_parse(NULL, 0);

		char *pCmd = (char *)req->getstr(req, "cmd", false);
		FILE *fp;
		char pBuff[256];

		qcgires_setcontenttype(pReq, "application/json");

		if (strcmp(pCmd, "get") == 0)
		{
				fp = popen("wdlxcmd get modem info", "r");
				while(fgets(pBuff, sizeof(pBuff), fp))
				{
						printf("%s", pBuff);
				}
				pclose(fp);
		} 
		return 0;
}
