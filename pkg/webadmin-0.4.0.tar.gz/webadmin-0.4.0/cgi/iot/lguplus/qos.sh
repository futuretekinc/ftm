

chat TIMEOUT 1 "" "AT+CGEQREQ=1,$1,$2,$3" "OK" > /dev/ttyS1
