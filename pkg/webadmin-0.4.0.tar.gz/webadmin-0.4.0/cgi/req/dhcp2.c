#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "qdecoder.h"

#define	TEMP_UDHCPD_CONF	"/tmp/_udhcpd"
#define	UDHCPD_CONF		"/etc/config/udhcpd"

int FTMC_DHCP2(qentry_t *pReq)
{
	int		nRet = 0;
	char	pCmdBuff[1024];
	char *pCmd = pReq->getstr(pReq, "cmd", false);
	
	qcgires_setcontenttype(pReq, "application/json");

	if (strcasecmp(pCmd, "get") == 0)
	{
		//qcgires_setcontenttype(pReq, "application/json");

		char	szBuf[1024];

		memset(szBuf, 0, sizeof(szBuf));

		FILE *pPF = popen("/www/cgi-bin/scripts/dhcp.sh get", "r");
		if (pPF == NULL)
		{
			nRet = -1;
			goto error;
		}

		while(fgets(szBuf, sizeof(szBuf) - 1, pPF) != 0)
		{
			printf("%s", szBuf);
		}
		printf(",");

		pclose(pPF);
	}
	else if(strcasecmp(pCmd, "set") == 0)
	{
		char *pEnable	= pReq->getstr(pReq, "enable", false);
		char *pInterface= pReq->getstr(pReq, "if", false);
		char *pStatic	= pReq->getstr(pReq, "static", false);
		char *pStart	= pReq->getstr(pReq, "start", false);
		char *pEnd		= pReq->getstr(pReq, "end", false);
		char *pRouter	= pReq->getstr(pReq, "router", false);
		char *pTime		= pReq->getstr(pReq, "time", false);
		char *pDNS1		= pReq->getstr(pReq, "dns1", false);
		char *pDNS2		= pReq->getstr(pReq, "dns2", false);

		if ((pEnable == NULL) || 
			(pInterface == NULL) || 
			(pStatic == NULL) || 
			(pStart == NULL) || 
			(pEnd == NULL) || 
			(pTime == NULL) ||
			(pDNS1 == NULL) ||
			(pDNS2 == NULL))
		{
			nRet = -1;
			goto error;
		}

		FILE *pFP  = fopen(TEMP_UDHCPD_CONF, "w");
		if (pFP == NULL)
		{
			nRet = -1;
			goto error;
		}

		fprintf(pFP, "config udhcpd\n");
		fprintf(pFP, "\toption\tenable\t%d\n", (strcasecmp(pEnable, "true") == 0));
		fprintf(pFP, "\toption\tinterface\t%s\n", pInterface);
		fprintf(pFP, "\toption\tstatic\t%d\n", ((pStatic != NULL) && (strcasecmp(pStatic, "true") == 0)));
		fprintf(pFP, "\toption\tstart\t%s\n", pStart);
		fprintf(pFP, "\toption\tend\t%s\n", pEnd);

		if (pTime != NULL)
		{
			fprintf(pFP, "\toption\tlease\t%s\n", pTime);
		}
		if (pRouter != NULL)
		{
			fprintf(pFP, "\toption\trouter\t%s\n", pRouter);
		}

		if (pDNS1 != NULL)
		{
			fprintf(pFP, "\n");
			fprintf(pFP, "config dns\n");
			fprintf(pFP, "\toption\thost\t%s\n", pDNS1);
		}
		
		if (pDNS2 != NULL)
		{
			fprintf(pFP, "\n");
			fprintf(pFP, "config dns\n");
			fprintf(pFP, "\toption\thost\t%s\n", pDNS2);
		}


		for(int i = 0 ; ; i++)
		{
			char *pMAC = (char *)pReq->getstrf(pReq, false, "mac%d", i);
			char *pIP = (char *)pReq->getstrf(pReq, false, "ip%d", i);

			if ((pMAC == NULL) || (pIP == NULL))
			{
				break;
			}

			for(int i = 0 ; i < strlen(pMAC) ; i++)
			{
				pMAC[i] = toupper(pMAC[i]);
			}

			fprintf(pFP, "\n");
			fprintf(pFP, "config static_lease\n");	
			fprintf(pFP, "\toption\tmac\t%s\n", pMAC);
			fprintf(pFP, "\toption\tip\t%s\n", pIP);
		}
		fclose(pFP);

		sprintf(pCmdBuff, "/bin/cp -f %s %s;sync;sync", TEMP_UDHCPD_CONF, UDHCPD_CONF);
		pFP = popen(pCmdBuff, "r");

		printf("{");

		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "start") == 0)
	{
		FILE *pFP = popen("/etc/init.d/udhcpd start", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "stop") == 0)
	{
		FILE *pFP = popen("/etc/init.d/udhcpd stop", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "restart") == 0)
	{
		printf("{");
		FILE *pFP = popen("/etc/init.d/udhcpd restart", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "enable") == 0)
	{
		FILE *pFP = popen("/etc/init.d/udhcpd enable", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "disable") == 0)
	{
		FILE *pFP = popen("/etc/init.d/udhcpd disable", "r");
		pclose(pFP);
	}
	else
	{
		nRet = -1;	
	}

error:
	
	printf("\"result\":\"%s\"}", (nRet == 0)?"success":"failed");

	return	nRet;
}
