#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "qdecoder.h"
#include "debug.h"
#include "util.h"

int	FTMC_Netfilter(qentry_t *pReq)
{
	int		nRet = 0;
    char	*pCmd = pReq->getstr(pReq, "cmd", false);
	FILE	*pFP;

	qcgires_setcontenttype(pReq, "application/json");
	printf("{\n");
    if (strcasecmp(pCmd, "get") == 0)
    {
		char	szBuf[1024];

		memset(szBuf, 0, sizeof(szBuf));

		pFP = popen("/www/cgi-bin/scripts/netfilter.sh get", "r");
		if (pFP == NULL)
		{	
			nRet = -1;
			goto error;
		}

		printf("\"netfilter\":");
		while(fgets(szBuf, sizeof(szBuf) - 1, pFP) != 0)
		{
			printf("%s", szBuf);
		}

		printf(",");
	
		pclose(pFP);
		pFP = NULL;

    }
    else if (strcasecmp(pCmd, "set") == 0)
    {
		int		i = 0; 

		pFP = fopen("/tmp/_firewall_usr", "w");
		if (pFP == NULL)
		{
			nRet = -1;
			goto error;
		}

		for(i = 0 ; ; i++)
		{
			char	*pTarget= pReq->getstrf(pReq, false, "target%d", i);
			char	*pName	= pReq->getstrf(pReq, false, "name%d", i);
			char	*pMatch = pReq->getstrf(pReq, false, "match%d", i);
			char	*pProto	= pReq->getstrf(pReq, false, "proto%d", i);
			char	*pPort	= pReq->getstrf(pReq, false, "port%d", i);
			char	*pPolicy= pReq->getstrf(pReq, false, "policy%d", i);

			if (pName == NULL)
			{
				break;
			}

			if (pPolicy == NULL)
			{
				fclose(pFP);
				goto error;	
			}

			fprintf(pFP, "config rule\n");
			fprintf(pFP, "\toption\ttarget\t%s\n", (pTarget != NULL)?pTarget:"all");
			fprintf(pFP, "\toption\tname\t%s\n", pName);
			fprintf(pFP, "\toption\tproto\t%s\n", (pProto != NULL)?pProto:"all");
			if (pPort != NULL)
			{
				fprintf(pFP, "\toption\tport\t%s\n", pPort);
			}
			if (pMatch != NULL)
			{
				fprintf(pFP, "\toption\tmatch\t%s\n", pMatch);
			}
			fprintf(pFP, "\toption\tpolicy\t%s\n", (pPolicy!= NULL)?pPolicy:"ACCEPT");
		}

		fclose(pFP);
	

		pFP = popen("cp -f /tmp/_firewall_usr /etc/config/firewall_usr;sync;rm /tmp/_firewall_usr; sync", "r");
		pclose(pFP);
    }
	else if (strcasecmp(pCmd, "start") == 0)
	{
		pFP = popen("/etc/init.d/firewall start", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "stop") == 0)
	{
		pFP = popen("/etc/init.d/firewall stop", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "restart") == 0)
	{
		pFP = popen("/etc/init.d/firewall restart", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "enable") == 0)
	{
		pFP = popen("/etc/init.d/firewall enable", "r");
		pclose(pFP);
	}
	else if (strcasecmp(pCmd, "disable") == 0)
	{
		pFP = popen("/etc/init.d/firewall disable", "r");
		pclose(pFP);
	}
	else
	{
		nRet = -1;
	}

error:
	if (nRet == 0)
	{
		printf("\t\"result\" : \"success\"\n");
	}
	else
	{
		printf("\t\"result\" : \"error\"\n");
	}
	printf("}\n");

	return	0;
}

