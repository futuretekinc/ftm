#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "qdecoder.h"

#define	TEMP_UDHCPD_CONF	"/tmp/_udhcpd"
#define	UDHCPD_CONF		"/etc/config/udhcpd"

int FTMC_DHCP(qentry_t *pReq)
{

	char	lpszCmdBuff[1024];
	char *lpszCmd = pReq->getstr(pReq, "cmd", false);

	if (strcasecmp(lpszCmd, "status") == 0)
	{
		qcgires_setcontenttype(pReq, "text/xml");
		printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
		printf("<DHCP_SERVER>\n");

		char	szBuf[1024];
		FILE *pPF = popen("/www/cgi-bin/status_dhcp.sh", "r");
		if (pPF != NULL)
		{
			while(fgets(szBuf, sizeof(szBuf), pPF) != 0)
			{
				char	szTag[64];	
				char	szData0[64];
				char	szData1[64];
				
				switch(sscanf(szBuf, "%s %s %s", szTag, szData0, szData1))
				{
				case	2:
					{
						if (strcasecmp(szTag, "STATUS:") == 0)
						{
							printf("<STATUS>%s</STATUS>\n", szData0);					
						}
						else if (strcasecmp(szTag, "INTERFACE:") == 0)
						{
							printf("<INTERFACE>%s</INTERFACE>\n", szData0);					
						}
						else if (strcasecmp(szTag, "START:") == 0)
						{
							printf("<START>%s</START>\n", szData0);					
						}
						else if (strcasecmp(szTag, "END:") == 0)
						{
							printf("<END>%s</END>\n", szData0);					
						}
						else if (strcasecmp(szTag, "ROUTER:") == 0)
						{
							printf("<ROUTER>%s</ROUTER>\n", szData0);					
						}
						else if (strcasecmp(szTag, "TIME:") == 0)
						{
							printf("<TIME>%s</TIME>\n", szData0);					
						}
						else if (strcasecmp(szTag, "STATIC:") == 0)
						{
							printf("<STATIC>%s</STATIC>\n", szData0);					
						}
						else if (strcasecmp(szTag, "DNS1:") == 0)
						{
							printf("<DNS1>%s</DNS1>\n", szData0);					
						}
						else if (strcasecmp(szTag, "DNS2:") == 0)
						{
							printf("<DNS2>%s</DNS2>\n", szData0);					
						}

					}
					break;

				case	3:
					{
						if (strcasecmp(szTag, "STATIC_LEASE:") == 0)
						{
							printf("<STATIC_LEASE>\n");
							printf("<MAC>%s</MAC>\n", szData0);
							printf("<IP>%s</IP>\n", szData1);
							printf("</STATIC_LEASE>\n");
						}
					}		
				}
			}
			pclose(pPF);
		}


		pPF = popen("/usr/bin/dumpleases | awk -f /www/cgi-bin/parse_dumpleases.awk", "r");
		if (pPF != NULL)
		{
			while(fgets(szBuf, sizeof(szBuf), pPF) != 0)
			{
				char	szTag[64];	
				char	szData[3][64];

				int		nArgs = sscanf(szBuf, "%s %s %s %s", szTag, szData[0], szData[1], szData[2]);

				if (strcasecmp(szTag, "<START>") == 0)
				{
					printf("<LEASE>\n");
				}
				else if (strcasecmp(szTag, "<END>") == 0)
				{
					printf("</LEASE>\n");
				}
				else if (strcasecmp(szTag, "MAC:") == 0)
				{
					printf("<MAC>%s</MAC>\n", szData[0]);
				}
				else if (strcasecmp(szTag, "IP:") == 0)
				{
					printf("<IP>%s</IP>\n", szData[0]);
				}
				else if (strcasecmp(szTag, "HOSTNAME:") == 0)
				{
					printf("<HOSTNAME>");
					if (nArgs > 1)
					{
						for(int i = 0 ; i < nArgs - 1; i++)
						{
							printf("%s ", szData[i]);
						}
					}
					printf("</HOSTNAME>\n");
				}
				else if (strcasecmp(szTag, "EXPIRESIN:") == 0)
				{
					printf("<EXPIRESIN>");
					if (nArgs > 1)
					{
						for(int i = 0 ; i < nArgs - 1; i++)
						{
							printf("%s ", szData[i]);
						}
					}
					printf("</EXPIRESIN>\n");
				}
				
			}

			pclose(pPF);
		}

		printf("</DHCP_SERVER>\n");
	}
	else if (strcasecmp(lpszCmd, "real_status") == 0)
	{
		qcgires_setcontenttype(pReq, "text/xml");
		printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
		printf("<ACTIVE_IP>\n");

		char	szBuf[1024];
		FILE *pPF = popen("arp -i lan | awk -f /www/cgi-bin/scripts/parse_arp.awk", "r");
		if (pPF != NULL)
		{
			while(fgets(szBuf, sizeof(szBuf), pPF) != 0)
			{
				char	szTag[64];	
				char	szData0[64];
				char	szData1[64];
				
				switch(sscanf(szBuf, "%s %s %s", szTag, szData0, szData1))
				{
				case	2:
					{
						if (strcasecmp(szTag, "IP:") == 0)
						{
							printf("<IP>%s</IP>\n", szData0);					
						}
					}
					break;
				}
			}
			pclose(pPF);
		}
		printf("</ACTIVE_IP>\n");
	}
	else if (strcasecmp(lpszCmd, "config") == 0)
	{
	}
	else if(strcasecmp(lpszCmd, "set") == 0)
	{
		char *lpszEnable	= pReq->getstr(pReq, "enable", false);
		char *lpszInterface = pReq->getstr(pReq, "if", false);
		char *lpszStatic	= pReq->getstr(pReq, "static", false);
		char *lpszStart		= pReq->getstr(pReq, "start", false);
		char *lpszEnd		= pReq->getstr(pReq, "end", false);
		char *lpszRouter	= pReq->getstr(pReq, "router", false);
		char *lpszTime		= pReq->getstr(pReq, "time", false);
		char *lpszDNS1		= pReq->getstr(pReq, "dns1", false);
		char *lpszDNS2		= pReq->getstr(pReq, "dns2", false);

		if ((lpszEnable == NULL) || 
			(lpszInterface == NULL) || 
			(lpszStatic == NULL) || 
			(lpszStart == NULL) || 
			(lpszEnd == NULL) || 
			(lpszTime == NULL) ||
			(lpszDNS1 == NULL) ||
			(lpszDNS2 == NULL))
		{
			qcgires_setcontenttype(pReq, "text/xml");
			printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
			printf("<DHCP_CONFIG>\n");	
			printf("<RET>ERROR</RET>\n");
			printf("<MSG>Invalid Parameter!</MSG>\n");
			printf("</DHCP_CONFIG>\n");	
			return	-1;	
		}

		FILE *fp = fopen(TEMP_UDHCPD_CONF, "w");
		if (fp == NULL)
		{
			qcgires_setcontenttype(pReq, "text/xml");
			printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
			printf("<DHCP_CONFIG>\n");	
			printf("<RET>SYSTEM_ERROR</RET>\n");
			printf("<MSG>Can't create file\n[/tmp/udhcpd.conf]</MSG>\n");
			printf("</DHCP_CONFIG>\n");	
			return	-1;	
		}

		fprintf(fp, "config udhcpd\n");
		fprintf(fp, "\toption\tenable\t%d\n", (strcasecmp(lpszEnable, "true") == 0));
		fprintf(fp, "\toption\tinterface\t%s\n", lpszInterface);
		fprintf(fp, "\toption\tstatic\t%d\n", ((lpszStatic != NULL) && (strcasecmp(lpszStatic, "true") == 0)));
		fprintf(fp, "\toption\tstart\t%s\n", lpszStart);
		fprintf(fp, "\toption\tend\t%s\n", lpszEnd);

		if (lpszTime != NULL)
		{
			fprintf(fp, "\toption\tlease\t%s\n", lpszTime);
		}
		if (lpszRouter != NULL)
		{
			fprintf(fp, "\toption\trouter\t%s\n", lpszRouter);
		}

		if (lpszDNS1 != NULL)
		{
			fprintf(fp, "\n");
			fprintf(fp, "config dns\n");
			fprintf(fp, "\toption\thost\t%s\n", lpszDNS1);
		}
		
		if (lpszDNS2 != NULL)
		{
			fprintf(fp, "\n");
			fprintf(fp, "config dns\n");
			fprintf(fp, "\toption\thost\t%s\n", lpszDNS2);
		}


		for(int i = 0 ; ; i++)
		{
			char *lpszMAC = (char *)pReq->getstrf(pReq, false, "mac%d", i);
			char *lpszIP = (char *)pReq->getstrf(pReq, false, "ip%d", i);

			if ((lpszMAC == NULL) || (lpszIP == NULL))
			{
				break;
			}

			for(int i = 0 ; i < strlen(lpszMAC) ; i++)
			{
				lpszMAC[i] = toupper(lpszMAC[i]);
			}

			fprintf(fp, "\n");
			fprintf(fp, "config static_lease\n");	
			fprintf(fp, "\toption\tmac\t%s\n", lpszMAC);
			fprintf(fp, "\toption\tip\t%s\n", lpszIP);
		}
		fclose(fp);

		sprintf(lpszCmdBuff, "/bin/cp -f %s %s;sync;sync", TEMP_UDHCPD_CONF, UDHCPD_CONF);
		fp = popen(lpszCmdBuff, "r");
		pclose(fp);


		fp = popen("/etc/init.d/udhcpd restart", "r");
		pclose(fp);

		qcgires_setcontenttype(pReq, "text/xml");
		printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
		printf("<DHCP_CONFIG>\n");
		printf("<RET>OK</RET>\n");
		printf("</DHCP_CONFIG>\n");
	}
	else
	{
		return	-1;	
	}

	return	0;
}
