
g2_diags -41 0xf4923000 2 r1.txt
g2_diags -41 0xf4923000 3 r2.txt

