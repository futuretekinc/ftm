package PerlIO::via;
our $VERSION = '0.04';
use XSLoader ();
XSLoader::load 'PerlIO::via';
1;
__END__

