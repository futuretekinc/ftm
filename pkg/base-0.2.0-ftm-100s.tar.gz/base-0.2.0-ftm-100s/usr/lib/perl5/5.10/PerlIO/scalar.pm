package PerlIO::scalar;
our $VERSION = '0.05';
use XSLoader ();
XSLoader::load 'PerlIO::scalar';
1;
__END__

