
return <<'END';
0901	0939	Devanagari
093C	094D	Devanagari
0950	0954	Devanagari
0958	0963	Devanagari
0966	096F	Devanagari
097B	097F	Devanagari
END
