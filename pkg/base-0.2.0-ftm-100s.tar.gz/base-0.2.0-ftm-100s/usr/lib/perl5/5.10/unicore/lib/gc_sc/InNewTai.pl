
return <<'END';
1980	19DF	New Tai Lue
END
