
return <<'END';
0000	007F	Basic Latin
END
