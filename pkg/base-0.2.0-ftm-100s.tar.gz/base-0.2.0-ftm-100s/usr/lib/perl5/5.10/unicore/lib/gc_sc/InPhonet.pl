
return <<'END';
1D00	1D7F	Phonetic Extensions
END
