
return <<'END';
2580	259F	Block Elements
END
