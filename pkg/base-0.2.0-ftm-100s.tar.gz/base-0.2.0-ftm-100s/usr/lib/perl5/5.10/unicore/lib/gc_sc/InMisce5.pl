
return <<'END';
2980	29FF	Miscellaneous Mathematical Symbols-B
END
