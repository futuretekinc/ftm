
return <<'END';
0500	052F	Cyrillic Supplement
END
