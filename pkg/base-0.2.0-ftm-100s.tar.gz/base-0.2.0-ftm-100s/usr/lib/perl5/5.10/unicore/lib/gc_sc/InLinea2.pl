
return <<'END';
10000	1007F	Linear B Syllabary
END
