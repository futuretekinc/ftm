
return <<'END';
0340	0341	Deprecated
17A3		Deprecated
17D3		Deprecated
206A	206F	Deprecated
END
