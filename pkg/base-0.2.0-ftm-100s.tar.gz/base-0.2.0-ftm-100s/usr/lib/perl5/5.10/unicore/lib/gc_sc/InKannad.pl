
return <<'END';
0C80	0CFF	Kannada
END
