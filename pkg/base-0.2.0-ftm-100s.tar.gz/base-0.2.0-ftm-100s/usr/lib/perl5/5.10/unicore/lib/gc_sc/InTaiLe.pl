
return <<'END';
1950	197F	Tai Le
END
