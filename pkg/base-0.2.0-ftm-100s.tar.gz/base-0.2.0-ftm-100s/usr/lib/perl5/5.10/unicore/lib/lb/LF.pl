
return <<'END';
000A		
END
