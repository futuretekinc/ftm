
return <<'END';
0069	006A	Soft_Dotted
012F		Soft_Dotted
0249		Soft_Dotted
0268		Soft_Dotted
029D		Soft_Dotted
02B2		Soft_Dotted
03F3		Soft_Dotted
0456		Soft_Dotted
0458		Soft_Dotted
1D62		Soft_Dotted
1D96		Soft_Dotted
1DA4		Soft_Dotted
1DA8		Soft_Dotted
1E2D		Soft_Dotted
1ECB		Soft_Dotted
2071		Soft_Dotted
2148	2149	Soft_Dotted
1D422	1D423	Soft_Dotted
1D456	1D457	Soft_Dotted
1D48A	1D48B	Soft_Dotted
1D4BE	1D4BF	Soft_Dotted
1D4F2	1D4F3	Soft_Dotted
1D526	1D527	Soft_Dotted
1D55A	1D55B	Soft_Dotted
1D58E	1D58F	Soft_Dotted
1D5C2	1D5C3	Soft_Dotted
1D5F6	1D5F7	Soft_Dotted
1D62A	1D62B	Soft_Dotted
1D65E	1D65F	Soft_Dotted
1D692	1D693	Soft_Dotted
END
