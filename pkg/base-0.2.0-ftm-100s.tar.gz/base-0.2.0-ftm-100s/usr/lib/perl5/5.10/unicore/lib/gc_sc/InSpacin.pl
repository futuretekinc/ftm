
return <<'END';
02B0	02FF	Spacing Modifier Letters
END
