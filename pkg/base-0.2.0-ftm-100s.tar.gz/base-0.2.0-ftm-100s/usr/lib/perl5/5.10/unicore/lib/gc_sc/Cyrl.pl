
return <<'END';
0400	0486	Cyrillic
0488	0513	Cyrillic
1D2B		Cyrillic
1D78		Cyrillic
END
