
return <<'END';
2440	245F	Optical Character Recognition
END
