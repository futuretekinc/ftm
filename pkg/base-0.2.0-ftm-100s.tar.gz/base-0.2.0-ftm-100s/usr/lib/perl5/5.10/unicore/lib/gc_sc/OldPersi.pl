
return <<'END';
103A0	103C3	Old_Persian
103C8	103D5	Old_Persian
END
