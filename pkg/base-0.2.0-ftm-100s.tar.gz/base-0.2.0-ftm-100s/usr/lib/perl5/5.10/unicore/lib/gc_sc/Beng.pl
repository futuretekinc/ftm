
return <<'END';
0981	0983	Bengali
0985	098C	Bengali
098F	0990	Bengali
0993	09A8	Bengali
09AA	09B0	Bengali
09B2		Bengali
09B6	09B9	Bengali
09BC	09C4	Bengali
09C7	09C8	Bengali
09CB	09CE	Bengali
09D7		Bengali
09DC	09DD	Bengali
09DF	09E3	Bengali
09E6	09FA	Bengali
END
