
return <<'END';
3040	309F	Hiragana
END
