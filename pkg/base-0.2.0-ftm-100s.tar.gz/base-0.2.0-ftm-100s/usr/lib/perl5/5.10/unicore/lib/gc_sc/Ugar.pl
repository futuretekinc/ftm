
return <<'END';
10380	1039D	Ugaritic
1039F		Ugaritic
END
