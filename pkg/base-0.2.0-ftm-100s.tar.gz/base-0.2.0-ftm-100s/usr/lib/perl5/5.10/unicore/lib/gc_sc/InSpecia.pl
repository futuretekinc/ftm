
return <<'END';
FFF0	FFFF	Specials
END
