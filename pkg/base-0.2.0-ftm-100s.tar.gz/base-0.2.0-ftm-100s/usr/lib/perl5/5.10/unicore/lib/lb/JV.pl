
return <<'END';
1160	11A2	
END
