
return <<'END';
0780	07B1	Thaana
END
