
return <<'END';
1780	17FF	Khmer
END
