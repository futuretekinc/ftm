
return <<'END';
1200	1248	Ethiopic
124A	124D	Ethiopic
1250	1256	Ethiopic
1258		Ethiopic
125A	125D	Ethiopic
1260	1288	Ethiopic
128A	128D	Ethiopic
1290	12B0	Ethiopic
12B2	12B5	Ethiopic
12B8	12BE	Ethiopic
12C0		Ethiopic
12C2	12C5	Ethiopic
12C8	12D6	Ethiopic
12D8	1310	Ethiopic
1312	1315	Ethiopic
1318	135A	Ethiopic
135F	137C	Ethiopic
1380	1399	Ethiopic
2D80	2D96	Ethiopic
2DA0	2DA6	Ethiopic
2DA8	2DAE	Ethiopic
2DB0	2DB6	Ethiopic
2DB8	2DBE	Ethiopic
2DC0	2DC6	Ethiopic
2DC8	2DCE	Ethiopic
2DD0	2DD6	Ethiopic
2DD8	2DDE	Ethiopic
END
