
return <<'END';
2600	26FF	Miscellaneous Symbols
END
