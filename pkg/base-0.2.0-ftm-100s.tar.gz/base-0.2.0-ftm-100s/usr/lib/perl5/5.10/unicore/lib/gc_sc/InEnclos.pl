
return <<'END';
2460	24FF	Enclosed Alphanumerics
END
