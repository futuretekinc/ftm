
return <<'END';
10450	1047F	Shavian
END
