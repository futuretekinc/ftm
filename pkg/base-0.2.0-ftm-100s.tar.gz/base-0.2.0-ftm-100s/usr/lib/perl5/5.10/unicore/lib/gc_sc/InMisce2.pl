
return <<'END';
2300	23FF	Miscellaneous Technical
END
