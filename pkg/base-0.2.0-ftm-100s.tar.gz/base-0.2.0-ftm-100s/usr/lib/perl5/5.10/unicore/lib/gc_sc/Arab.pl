
return <<'END';
060B		Arabic
060D	0615	Arabic
061E		Arabic
0621	063A	Arabic
0641	064A	Arabic
0656	065E	Arabic
066A	066F	Arabic
0671	06DC	Arabic
06DE	06FF	Arabic
0750	076D	Arabic
FB50	FBB1	Arabic
FBD3	FD3D	Arabic
FD50	FD8F	Arabic
FD92	FDC7	Arabic
FDF0	FDFC	Arabic
FE70	FE74	Arabic
FE76	FEFC	Arabic
END
