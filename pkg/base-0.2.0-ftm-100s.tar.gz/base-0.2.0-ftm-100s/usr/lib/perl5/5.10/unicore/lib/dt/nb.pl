
return <<'END';
00A0		
0F0C		
2007		
2011		
202F		
END
