
return <<'END';
0080	00FF	Latin-1 Supplement
END
