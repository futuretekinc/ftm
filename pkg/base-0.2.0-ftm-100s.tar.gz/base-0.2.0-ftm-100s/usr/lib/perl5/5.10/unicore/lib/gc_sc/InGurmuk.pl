
return <<'END';
0A00	0A7F	Gurmukhi
END
