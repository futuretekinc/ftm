
return <<'END';
10900	1091F	Phoenician
END
