
return <<'END';
2F800	2FA1F	CJK Compatibility Ideographs Supplement
END
