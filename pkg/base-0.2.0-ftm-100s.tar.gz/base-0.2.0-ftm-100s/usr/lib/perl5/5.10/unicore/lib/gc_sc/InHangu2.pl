
return <<'END';
AC00	D7AF	Hangul Syllables
END
