
return <<'END';
1700	171F	Tagalog
END
