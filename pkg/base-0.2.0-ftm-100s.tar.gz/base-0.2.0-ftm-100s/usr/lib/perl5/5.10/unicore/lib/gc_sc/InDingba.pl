
return <<'END';
2700	27BF	Dingbats
END
