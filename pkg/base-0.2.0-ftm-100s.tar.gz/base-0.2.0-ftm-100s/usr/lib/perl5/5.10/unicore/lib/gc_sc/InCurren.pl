
return <<'END';
20A0	20CF	Currency Symbols
END
