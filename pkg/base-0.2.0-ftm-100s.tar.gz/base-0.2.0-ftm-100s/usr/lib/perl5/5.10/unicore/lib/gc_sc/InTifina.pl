
return <<'END';
2D30	2D7F	Tifinagh
END
