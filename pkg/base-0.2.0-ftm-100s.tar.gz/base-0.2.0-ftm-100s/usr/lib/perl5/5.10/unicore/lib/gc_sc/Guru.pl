
return <<'END';
0A01	0A03	Gurmukhi
0A05	0A0A	Gurmukhi
0A0F	0A10	Gurmukhi
0A13	0A28	Gurmukhi
0A2A	0A30	Gurmukhi
0A32	0A33	Gurmukhi
0A35	0A36	Gurmukhi
0A38	0A39	Gurmukhi
0A3C		Gurmukhi
0A3E	0A42	Gurmukhi
0A47	0A48	Gurmukhi
0A4B	0A4D	Gurmukhi
0A59	0A5C	Gurmukhi
0A5E		Gurmukhi
0A66	0A74	Gurmukhi
END
