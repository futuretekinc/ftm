
return <<'END';
2D30	2D65	Tifinagh
2D6F		Tifinagh
END
