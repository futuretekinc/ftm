
return <<'END';
3041	3096	Hiragana
309D	309F	Hiragana
END
