
return <<'END';
200E	200F	Bidi_Control
202A	202E	Bidi_Control
END
