
return <<'END';
13A0	13FF	Cherokee
END
