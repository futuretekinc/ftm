
return <<'END';
2900	297F	Supplemental Arrows-B
END
