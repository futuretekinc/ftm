
return <<'END';
2190	21FF	Arrows
END
