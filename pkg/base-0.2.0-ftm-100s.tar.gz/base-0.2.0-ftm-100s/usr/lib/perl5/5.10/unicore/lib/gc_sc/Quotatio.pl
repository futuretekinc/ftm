
return <<'END';
0022		Quotation_Mark
0027		Quotation_Mark
00AB		Quotation_Mark
00BB		Quotation_Mark
2018	201F	Quotation_Mark
2039	203A	Quotation_Mark
300C	300F	Quotation_Mark
301D	301F	Quotation_Mark
FE41	FE44	Quotation_Mark
FF02		Quotation_Mark
FF07		Quotation_Mark
FF62	FF63	Quotation_Mark
END
