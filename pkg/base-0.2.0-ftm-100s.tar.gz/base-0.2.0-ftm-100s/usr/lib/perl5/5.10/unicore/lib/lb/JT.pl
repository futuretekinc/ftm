
return <<'END';
11A8	11F9	
END
