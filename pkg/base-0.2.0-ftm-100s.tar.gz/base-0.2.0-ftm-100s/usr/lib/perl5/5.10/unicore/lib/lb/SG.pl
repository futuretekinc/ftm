
return <<'END';
D800	DFFF	
END
