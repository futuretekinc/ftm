
return <<'END';
2C00	2C2E	Glagolitic
2C30	2C5E	Glagolitic
END
