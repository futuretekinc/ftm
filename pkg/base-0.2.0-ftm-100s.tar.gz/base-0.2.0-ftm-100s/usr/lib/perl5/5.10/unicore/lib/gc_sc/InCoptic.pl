
return <<'END';
2C80	2CFF	Coptic
END
