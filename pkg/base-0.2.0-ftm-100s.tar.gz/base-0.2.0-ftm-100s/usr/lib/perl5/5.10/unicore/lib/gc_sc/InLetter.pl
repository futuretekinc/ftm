
return <<'END';
2100	214F	Letterlike Symbols
END
