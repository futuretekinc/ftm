
return <<'END';
10330	1034F	Gothic
END
