
return <<'END';
2160	216F	Other_Uppercase
24B6	24CF	Other_Uppercase
END
