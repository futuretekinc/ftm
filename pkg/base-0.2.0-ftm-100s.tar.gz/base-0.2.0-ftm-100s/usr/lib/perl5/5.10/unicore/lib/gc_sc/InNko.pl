
return <<'END';
07C0	07FF	NKo
END
