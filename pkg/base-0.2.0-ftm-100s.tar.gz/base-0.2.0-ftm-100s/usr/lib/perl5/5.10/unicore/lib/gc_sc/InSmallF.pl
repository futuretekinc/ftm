
return <<'END';
FE50	FE6F	Small Form Variants
END
