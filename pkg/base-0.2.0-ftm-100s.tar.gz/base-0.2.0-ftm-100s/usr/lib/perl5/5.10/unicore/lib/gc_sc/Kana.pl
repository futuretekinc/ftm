
return <<'END';
30A1	30FA	Katakana
30FD	30FF	Katakana
31F0	31FF	Katakana
FF66	FF6F	Katakana
FF71	FF9D	Katakana
END
