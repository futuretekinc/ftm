
return <<'END';
10330	1034A	Gothic
END
