
return <<'END';
1400	167F	Unified Canadian Aboriginal Syllabics
END
