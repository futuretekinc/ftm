
return <<'END';
0021		Terminal_Punctuation
002C		Terminal_Punctuation
002E		Terminal_Punctuation
003A	003B	Terminal_Punctuation
003F		Terminal_Punctuation
037E		Terminal_Punctuation
0387		Terminal_Punctuation
0589		Terminal_Punctuation
05C3		Terminal_Punctuation
060C		Terminal_Punctuation
061B		Terminal_Punctuation
061F		Terminal_Punctuation
06D4		Terminal_Punctuation
0700	070A	Terminal_Punctuation
070C		Terminal_Punctuation
07F8	07F9	Terminal_Punctuation
0964	0965	Terminal_Punctuation
0E5A	0E5B	Terminal_Punctuation
0F08		Terminal_Punctuation
0F0D	0F12	Terminal_Punctuation
104A	104B	Terminal_Punctuation
1361	1368	Terminal_Punctuation
166D	166E	Terminal_Punctuation
16EB	16ED	Terminal_Punctuation
17D4	17D6	Terminal_Punctuation
17DA		Terminal_Punctuation
1802	1805	Terminal_Punctuation
1808	1809	Terminal_Punctuation
1944	1945	Terminal_Punctuation
1B5A	1B5B	Terminal_Punctuation
1B5D	1B5F	Terminal_Punctuation
203C	203D	Terminal_Punctuation
2047	2049	Terminal_Punctuation
3001	3002	Terminal_Punctuation
A876	A877	Terminal_Punctuation
FE50	FE52	Terminal_Punctuation
FE54	FE57	Terminal_Punctuation
FF01		Terminal_Punctuation
FF0C		Terminal_Punctuation
FF0E		Terminal_Punctuation
FF1A	FF1B	Terminal_Punctuation
FF1F		Terminal_Punctuation
FF61		Terminal_Punctuation
FF64		Terminal_Punctuation
1039F		Terminal_Punctuation
103D0		Terminal_Punctuation
1091F		Terminal_Punctuation
12470	12473	Terminal_Punctuation
END
