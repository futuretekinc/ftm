
return <<'END';
0E40	0E44	Logical_Order_Exception
0EC0	0EC4	Logical_Order_Exception
END
