
return <<'END';
27F0	27FF	Supplemental Arrows-A
END
