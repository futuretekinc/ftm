
return <<'END';
2000	206F	General Punctuation
END
