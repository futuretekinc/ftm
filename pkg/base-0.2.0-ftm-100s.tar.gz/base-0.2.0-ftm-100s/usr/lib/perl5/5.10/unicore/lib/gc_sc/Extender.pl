
return <<'END';
00B7		Extender
02D0	02D1	Extender
0640		Extender
07FA		Extender
0E46		Extender
0EC6		Extender
1843		Extender
3005		Extender
3031	3035	Extender
309D	309E	Extender
30FC	30FE	Extender
A015		Extender
FF70		Extender
END
