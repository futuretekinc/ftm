
return <<'END';
0D00	0D7F	Malayalam
END
