
return <<'END';
002D		Hyphen
00AD		Hyphen
058A		Hyphen
1806		Hyphen
2010	2011	Hyphen
2E17		Hyphen
30FB		Hyphen
FE63		Hyphen
FF0D		Hyphen
FF65		Hyphen
END
