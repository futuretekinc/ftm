
return <<'END';
0530	058F	Armenian
END
