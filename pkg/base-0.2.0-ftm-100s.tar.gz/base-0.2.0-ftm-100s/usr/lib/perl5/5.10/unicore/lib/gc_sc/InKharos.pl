
return <<'END';
10A00	10A5F	Kharoshthi
END
