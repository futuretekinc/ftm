
return <<'END';
0700	074F	Syriac
END
