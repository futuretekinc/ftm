
return <<'END';
09BE		Other_Grapheme_Extend
09D7		Other_Grapheme_Extend
0B3E		Other_Grapheme_Extend
0B57		Other_Grapheme_Extend
0BBE		Other_Grapheme_Extend
0BD7		Other_Grapheme_Extend
0CC2		Other_Grapheme_Extend
0CD5	0CD6	Other_Grapheme_Extend
0D3E		Other_Grapheme_Extend
0D57		Other_Grapheme_Extend
0DCF		Other_Grapheme_Extend
0DDF		Other_Grapheme_Extend
200C	200D	Other_Grapheme_Extend
1D165		Other_Grapheme_Extend
1D16E	1D172	Other_Grapheme_Extend
END
