
return <<'END';
2D00	2D2F	Georgian Supplement
END
