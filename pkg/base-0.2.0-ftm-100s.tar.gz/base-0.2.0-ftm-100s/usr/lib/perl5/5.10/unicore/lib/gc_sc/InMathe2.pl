
return <<'END';
1D400	1D7FF	Mathematical Alphanumeric Symbols
END
