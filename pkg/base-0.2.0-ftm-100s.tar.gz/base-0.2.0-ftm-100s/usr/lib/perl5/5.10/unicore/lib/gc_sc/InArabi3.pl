
return <<'END';
FE70	FEFF	Arabic Presentation Forms-B
END
