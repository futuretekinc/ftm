
return <<'END';
E0100	E01EF	Variation Selectors Supplement
END
