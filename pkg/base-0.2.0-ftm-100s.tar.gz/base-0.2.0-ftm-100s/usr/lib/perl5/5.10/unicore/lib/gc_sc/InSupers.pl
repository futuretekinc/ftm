
return <<'END';
2070	209F	Superscripts and Subscripts
END
