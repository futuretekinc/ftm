
return <<'END';
0009	000D	Pattern_White_Space
0020		Pattern_White_Space
0085		Pattern_White_Space
200E	200F	Pattern_White_Space
2028	2029	Pattern_White_Space
END
