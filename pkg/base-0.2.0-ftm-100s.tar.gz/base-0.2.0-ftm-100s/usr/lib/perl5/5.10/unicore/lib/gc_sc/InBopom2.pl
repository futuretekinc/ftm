
return <<'END';
31A0	31BF	Bopomofo Extended
END
