
return <<'END';
3400	4DBF	CJK Unified Ideographs Extension A
END
