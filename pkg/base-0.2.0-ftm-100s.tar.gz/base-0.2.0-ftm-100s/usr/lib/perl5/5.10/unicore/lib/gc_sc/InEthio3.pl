
return <<'END';
1380	139F	Ethiopic Supplement
END
