
return <<'END';
1740	175F	Buhid
END
