
return <<'END';
0780	07BF	Thaana
END
