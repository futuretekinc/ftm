
return <<'END';
0700	070D	Syriac
070F	074A	Syriac
074D	074F	Syriac
END
