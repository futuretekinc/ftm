
return <<'END';
10080	100FF	Linear B Ideograms
END
