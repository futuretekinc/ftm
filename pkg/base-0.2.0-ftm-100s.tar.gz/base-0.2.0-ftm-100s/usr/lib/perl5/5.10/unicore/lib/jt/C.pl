
return <<'END';
0640		
07FA		
200D		
END
