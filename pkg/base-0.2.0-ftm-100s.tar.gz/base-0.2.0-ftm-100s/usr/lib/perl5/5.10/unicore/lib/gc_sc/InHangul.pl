
return <<'END';
1100	11FF	Hangul Jamo
END
