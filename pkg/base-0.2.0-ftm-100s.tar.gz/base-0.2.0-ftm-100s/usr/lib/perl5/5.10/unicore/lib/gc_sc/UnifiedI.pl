
return <<'END';
3400	4DB5	Unified_Ideograph
4E00	9FBB	Unified_Ideograph
FA0E	FA0F	Unified_Ideograph
FA11		Unified_Ideograph
FA13	FA14	Unified_Ideograph
FA1F		Unified_Ideograph
FA21		Unified_Ideograph
FA23	FA24	Unified_Ideograph
FA27	FA29	Unified_Ideograph
20000	2A6D6	Unified_Ideograph
END
