
return <<'END';
DB80	DBFF	High Private Use Surrogates
END
