
return <<'END';
0D02	0D03	Malayalam
0D05	0D0C	Malayalam
0D0E	0D10	Malayalam
0D12	0D28	Malayalam
0D2A	0D39	Malayalam
0D3E	0D43	Malayalam
0D46	0D48	Malayalam
0D4A	0D4D	Malayalam
0D57		Malayalam
0D60	0D61	Malayalam
0D66	0D6F	Malayalam
END
