
return <<'END';
1760	177F	Tagbanwa
END
