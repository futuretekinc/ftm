
return <<'END';
2150	218F	Number Forms
END
