
return <<'END';
1000	1021	Myanmar
1023	1027	Myanmar
1029	102A	Myanmar
102C	1032	Myanmar
1036	1039	Myanmar
1040	1059	Myanmar
END
