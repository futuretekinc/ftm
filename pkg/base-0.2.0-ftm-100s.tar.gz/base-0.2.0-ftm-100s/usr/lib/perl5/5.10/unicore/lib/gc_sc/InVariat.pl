
return <<'END';
FE00	FE0F	Variation Selectors
END
