
return <<'END';
0021	002F	Pattern_Syntax
003A	0040	Pattern_Syntax
005B	005E	Pattern_Syntax
0060		Pattern_Syntax
007B	007E	Pattern_Syntax
00A1	00A7	Pattern_Syntax
00A9		Pattern_Syntax
00AB	00AC	Pattern_Syntax
00AE		Pattern_Syntax
00B0	00B1	Pattern_Syntax
00B6		Pattern_Syntax
00BB		Pattern_Syntax
00BF		Pattern_Syntax
00D7		Pattern_Syntax
00F7		Pattern_Syntax
2010	2027	Pattern_Syntax
2030	203E	Pattern_Syntax
2041	2053	Pattern_Syntax
2055	205E	Pattern_Syntax
2190	245F	Pattern_Syntax
2500	2775	Pattern_Syntax
2794	2BFF	Pattern_Syntax
2E00	2E7F	Pattern_Syntax
3001	3003	Pattern_Syntax
3008	3020	Pattern_Syntax
3030		Pattern_Syntax
FD3E	FD3F	Pattern_Syntax
FE45	FE46	Pattern_Syntax
END
