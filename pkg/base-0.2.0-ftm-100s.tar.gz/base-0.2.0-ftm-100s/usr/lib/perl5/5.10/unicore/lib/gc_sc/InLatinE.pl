
return <<'END';
0180	024F	Latin Extended-B
END
