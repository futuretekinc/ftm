
return <<'END';
180B	180D	Variation_Selector
FE00	FE0F	Variation_Selector
E0100	E01EF	Variation_Selector
END
