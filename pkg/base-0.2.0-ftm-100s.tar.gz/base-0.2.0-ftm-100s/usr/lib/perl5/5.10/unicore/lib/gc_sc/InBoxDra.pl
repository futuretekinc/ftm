
return <<'END';
2500	257F	Box Drawing
END
