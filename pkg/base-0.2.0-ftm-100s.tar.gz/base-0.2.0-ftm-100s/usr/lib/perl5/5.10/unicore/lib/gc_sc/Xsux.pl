
return <<'END';
12000	1236E	Cuneiform
12400	12462	Cuneiform
12470	12473	Cuneiform
END
