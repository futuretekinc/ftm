
return <<'END';
1800	18AF	Mongolian
END
