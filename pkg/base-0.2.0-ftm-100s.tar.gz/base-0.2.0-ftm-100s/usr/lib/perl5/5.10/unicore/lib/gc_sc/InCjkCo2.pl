
return <<'END';
FE30	FE4F	CJK Compatibility Forms
END
