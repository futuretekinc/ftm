
return <<'END';
0000	10FFFF	
END
