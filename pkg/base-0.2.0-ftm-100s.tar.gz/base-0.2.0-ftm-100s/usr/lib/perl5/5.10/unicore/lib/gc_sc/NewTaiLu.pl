
return <<'END';
1980	19A9	New_Tai_Lue
19B0	19C9	New_Tai_Lue
19D0	19D9	New_Tai_Lue
19DE	19DF	New_Tai_Lue
END
