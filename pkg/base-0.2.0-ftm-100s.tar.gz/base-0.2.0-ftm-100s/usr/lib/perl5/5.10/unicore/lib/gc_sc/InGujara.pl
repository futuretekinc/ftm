
return <<'END';
0A80	0AFF	Gujarati
END
