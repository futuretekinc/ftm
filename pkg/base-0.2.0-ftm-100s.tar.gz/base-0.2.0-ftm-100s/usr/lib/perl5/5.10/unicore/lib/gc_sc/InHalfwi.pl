
return <<'END';
FF00	FFEF	Halfwidth and Fullwidth Forms
END
