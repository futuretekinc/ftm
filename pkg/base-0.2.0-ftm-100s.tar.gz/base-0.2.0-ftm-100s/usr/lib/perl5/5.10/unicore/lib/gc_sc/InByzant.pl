
return <<'END';
1D000	1D0FF	Byzantine Musical Symbols
END
