
return <<'END';
002D		Dash
058A		Dash
05BE		Dash
1806		Dash
2010	2015	Dash
2053		Dash
207B		Dash
208B		Dash
2212		Dash
2E17		Dash
301C		Dash
3030		Dash
30A0		Dash
FE31	FE32	Dash
FE58		Dash
FE63		Dash
FF0D		Dash
END
