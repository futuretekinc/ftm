
return <<'END';
13A0	13F4	Cherokee
END
