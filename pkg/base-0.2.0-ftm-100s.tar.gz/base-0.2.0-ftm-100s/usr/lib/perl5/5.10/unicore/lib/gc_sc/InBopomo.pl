
return <<'END';
3100	312F	Bopomofo
END
