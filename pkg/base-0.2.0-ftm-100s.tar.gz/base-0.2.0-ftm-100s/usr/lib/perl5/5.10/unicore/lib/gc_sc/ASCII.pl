
return <<'END';
0000	007F	
END
