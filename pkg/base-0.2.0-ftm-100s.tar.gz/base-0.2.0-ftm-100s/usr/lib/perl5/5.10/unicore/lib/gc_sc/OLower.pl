
return <<'END';
02B0	02B8	Other_Lowercase
02C0	02C1	Other_Lowercase
02E0	02E4	Other_Lowercase
0345		Other_Lowercase
037A		Other_Lowercase
1D2C	1D61	Other_Lowercase
1D78		Other_Lowercase
1D9B	1DBF	Other_Lowercase
2090	2094	Other_Lowercase
2170	217F	Other_Lowercase
24D0	24E9	Other_Lowercase
END
