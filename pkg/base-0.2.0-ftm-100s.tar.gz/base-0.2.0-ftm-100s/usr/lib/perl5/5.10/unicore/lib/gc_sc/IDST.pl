
return <<'END';
2FF2	2FF3	IDS_Trinary_Operator
END
