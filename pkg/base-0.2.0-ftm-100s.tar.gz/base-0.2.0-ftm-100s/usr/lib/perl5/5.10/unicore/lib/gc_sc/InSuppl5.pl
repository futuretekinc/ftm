
return <<'END';
100000	10FFFF	Supplementary Private Use Area-B
END
