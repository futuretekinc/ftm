
return <<'END';
25A0	25FF	Geometric Shapes
END
