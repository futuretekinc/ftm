
return <<'END';
0531	0556	Armenian
0559	055F	Armenian
0561	0587	Armenian
058A		Armenian
FB13	FB17	Armenian
END
