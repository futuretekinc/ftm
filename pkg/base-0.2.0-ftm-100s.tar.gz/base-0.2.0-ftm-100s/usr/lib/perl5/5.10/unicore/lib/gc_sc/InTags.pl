
return <<'END';
E0000	E007F	Tags
END
