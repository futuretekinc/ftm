
return <<'END';
E000	F8FF	Private Use Area
END
