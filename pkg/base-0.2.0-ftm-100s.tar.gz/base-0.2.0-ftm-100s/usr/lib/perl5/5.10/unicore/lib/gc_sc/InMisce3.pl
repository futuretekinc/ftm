
return <<'END';
2B00	2BFF	Miscellaneous Symbols and Arrows
END
