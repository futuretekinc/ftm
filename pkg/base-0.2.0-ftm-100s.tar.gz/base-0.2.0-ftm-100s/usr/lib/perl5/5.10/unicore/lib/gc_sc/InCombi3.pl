
return <<'END';
1DC0	1DFF	Combining Diacritical Marks Supplement
END
