
return <<'END';
1A00	1A1F	Buginese
END
