
return <<'END';
19E0	19FF	Khmer Symbols
END
