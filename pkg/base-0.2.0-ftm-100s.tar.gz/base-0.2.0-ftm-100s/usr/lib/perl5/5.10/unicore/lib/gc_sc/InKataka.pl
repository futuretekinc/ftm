
return <<'END';
30A0	30FF	Katakana
END
