
return <<'END';
FE10	FE1F	Vertical Forms
END
