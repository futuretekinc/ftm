
return <<'END';
2A00	2AFF	Supplemental Mathematical Operators
END
