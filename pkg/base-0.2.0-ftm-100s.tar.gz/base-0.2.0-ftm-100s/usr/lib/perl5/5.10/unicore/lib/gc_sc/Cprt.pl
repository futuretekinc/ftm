
return <<'END';
10800	10805	Cypriot
10808		Cypriot
1080A	10835	Cypriot
10837	10838	Cypriot
1083C		Cypriot
1083F		Cypriot
END
