
return <<'END';
1F00	1FFF	Greek Extended
END
