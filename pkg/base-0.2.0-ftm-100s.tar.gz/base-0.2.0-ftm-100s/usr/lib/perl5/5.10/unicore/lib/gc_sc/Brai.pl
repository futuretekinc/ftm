
return <<'END';
2800	28FF	Braille
END
