
return <<'END';
A800	A82F	Syloti Nagri
END
