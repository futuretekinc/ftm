
return <<'END';
3300	33FF	CJK Compatibility
END
