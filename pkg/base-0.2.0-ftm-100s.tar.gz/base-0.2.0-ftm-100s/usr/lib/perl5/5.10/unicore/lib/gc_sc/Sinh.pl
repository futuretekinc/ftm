
return <<'END';
0D82	0D83	Sinhala
0D85	0D96	Sinhala
0D9A	0DB1	Sinhala
0DB3	0DBB	Sinhala
0DBD		Sinhala
0DC0	0DC6	Sinhala
0DCA		Sinhala
0DCF	0DD4	Sinhala
0DD6		Sinhala
0DD8	0DDF	Sinhala
0DF2	0DF4	Sinhala
END
