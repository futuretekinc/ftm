
return <<'END';
005E		Diacritic
0060		Diacritic
00A8		Diacritic
00AF		Diacritic
00B4		Diacritic
00B7	00B8	Diacritic
02B0	034E	Diacritic
0350	0357	Diacritic
035D	0362	Diacritic
0374	0375	Diacritic
037A		Diacritic
0384	0385	Diacritic
0483	0486	Diacritic
0559		Diacritic
0591	05A1	Diacritic
05A3	05BD	Diacritic
05BF		Diacritic
05C1	05C2	Diacritic
05C4		Diacritic
064B	0652	Diacritic
0657	0658	Diacritic
06DF	06E0	Diacritic
06E5	06E6	Diacritic
06EA	06EC	Diacritic
0730	074A	Diacritic
07A6	07B0	Diacritic
07EB	07F5	Diacritic
093C		Diacritic
094D		Diacritic
0951	0954	Diacritic
09BC		Diacritic
09CD		Diacritic
0A3C		Diacritic
0A4D		Diacritic
0ABC		Diacritic
0ACD		Diacritic
0B3C		Diacritic
0B4D		Diacritic
0BCD		Diacritic
0C4D		Diacritic
0CBC		Diacritic
0CCD		Diacritic
0D4D		Diacritic
0DCA		Diacritic
0E47	0E4C	Diacritic
0E4E		Diacritic
0EC8	0ECC	Diacritic
0F18	0F19	Diacritic
0F35		Diacritic
0F37		Diacritic
0F39		Diacritic
0F3E	0F3F	Diacritic
0F82	0F84	Diacritic
0F86	0F87	Diacritic
0FC6		Diacritic
1037		Diacritic
1039		Diacritic
17C9	17D3	Diacritic
17DD		Diacritic
1939	193B	Diacritic
1B34		Diacritic
1B44		Diacritic
1B6B	1B73	Diacritic
1D2C	1D6A	Diacritic
1DC4	1DCA	Diacritic
1DFE	1DFF	Diacritic
1FBD		Diacritic
1FBF	1FC1	Diacritic
1FCD	1FCF	Diacritic
1FDD	1FDF	Diacritic
1FED	1FEF	Diacritic
1FFD	1FFE	Diacritic
302A	302F	Diacritic
3099	309C	Diacritic
30FC		Diacritic
A717	A71A	Diacritic
A720	A721	Diacritic
FB1E		Diacritic
FE20	FE23	Diacritic
FF3E		Diacritic
FF40		Diacritic
FF70		Diacritic
FF9E	FF9F	Diacritic
FFE3		Diacritic
1D167	1D169	Diacritic
1D16D	1D172	Diacritic
1D17B	1D182	Diacritic
1D185	1D18B	Diacritic
1D1AA	1D1AD	Diacritic
END
