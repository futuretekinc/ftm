
return <<'END';
1720	1734	Hanunoo
END
