
return <<'END';
31F0	31FF	Katakana Phonetic Extensions
END
