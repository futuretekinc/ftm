
return <<'END';
2118		Other_ID_Start
212E		Other_ID_Start
309B	309C	Other_ID_Start
END
