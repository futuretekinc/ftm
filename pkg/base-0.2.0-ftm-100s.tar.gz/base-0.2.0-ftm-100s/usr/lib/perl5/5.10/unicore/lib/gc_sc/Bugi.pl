
return <<'END';
1A00	1A1B	Buginese
1A1E	1A1F	Buginese
END
