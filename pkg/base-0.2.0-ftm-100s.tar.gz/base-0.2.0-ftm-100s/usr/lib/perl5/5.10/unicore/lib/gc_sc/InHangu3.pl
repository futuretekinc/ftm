
return <<'END';
3130	318F	Hangul Compatibility Jamo
END
