
return <<'END';
1D200	1D24F	Ancient Greek Musical Notation
END
