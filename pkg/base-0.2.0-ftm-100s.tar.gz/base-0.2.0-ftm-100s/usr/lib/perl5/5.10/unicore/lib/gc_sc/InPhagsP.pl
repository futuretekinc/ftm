
return <<'END';
A840	A87F	Phags-pa
END
