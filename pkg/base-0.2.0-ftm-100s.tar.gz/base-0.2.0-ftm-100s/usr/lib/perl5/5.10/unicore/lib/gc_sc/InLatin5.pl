
return <<'END';
1E00	1EFF	Latin Extended Additional
END
