
return <<'END';
1B00	1B7F	Balinese
END
