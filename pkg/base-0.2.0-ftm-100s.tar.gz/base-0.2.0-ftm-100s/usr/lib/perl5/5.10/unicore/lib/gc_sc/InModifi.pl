
return <<'END';
A700	A71F	Modifier Tone Letters
END
