
return <<'END';
D800	DB7F	High Surrogates
END
