
return <<'END';
3006	3007	Ideographic
3021	3029	Ideographic
3038	303A	Ideographic
3400	4DB5	Ideographic
4E00	9FBB	Ideographic
F900	FA2D	Ideographic
FA70	FAD9	Ideographic
20000	2A6D6	Ideographic
2F800	2FA1D	Ideographic
END
