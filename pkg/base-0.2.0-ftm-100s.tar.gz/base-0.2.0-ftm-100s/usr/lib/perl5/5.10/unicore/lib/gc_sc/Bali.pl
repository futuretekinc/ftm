
return <<'END';
1B00	1B4B	Balinese
1B50	1B7C	Balinese
END
