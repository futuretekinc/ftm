
return <<'END';
0009	000D	White_Space
0020		White_Space
0085		White_Space
00A0		White_Space
1680		White_Space
180E		White_Space
2000	200A	White_Space
2028	2029	White_Space
202F		White_Space
205F		White_Space
3000		White_Space
END
