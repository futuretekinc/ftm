
return <<'END';
0E01	0E3A	Thai
0E40	0E5B	Thai
END
