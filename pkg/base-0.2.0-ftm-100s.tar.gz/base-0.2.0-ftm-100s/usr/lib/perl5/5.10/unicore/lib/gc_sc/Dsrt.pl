
return <<'END';
10400	1044F	Deseret
END
