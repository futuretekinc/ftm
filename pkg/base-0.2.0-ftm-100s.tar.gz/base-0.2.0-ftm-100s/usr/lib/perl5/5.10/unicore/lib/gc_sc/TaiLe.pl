
return <<'END';
1950	196D	Tai_Le
1970	1974	Tai_Le
END
