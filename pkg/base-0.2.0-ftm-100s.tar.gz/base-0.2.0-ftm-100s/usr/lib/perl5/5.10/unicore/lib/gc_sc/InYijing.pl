
return <<'END';
4DC0	4DFF	Yijing Hexagram Symbols
END
