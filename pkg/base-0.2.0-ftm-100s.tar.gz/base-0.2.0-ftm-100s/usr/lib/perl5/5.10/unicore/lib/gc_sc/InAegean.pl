
return <<'END';
10100	1013F	Aegean Numbers
END
