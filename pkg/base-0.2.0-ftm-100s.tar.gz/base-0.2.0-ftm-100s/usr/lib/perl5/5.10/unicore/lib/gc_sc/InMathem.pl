
return <<'END';
2200	22FF	Mathematical Operators
END
