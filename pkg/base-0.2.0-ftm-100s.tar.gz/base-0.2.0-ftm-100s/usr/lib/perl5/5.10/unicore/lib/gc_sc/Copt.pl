
return <<'END';
03E2	03EF	Coptic
2C80	2CEA	Coptic
2CF9	2CFF	Coptic
END
