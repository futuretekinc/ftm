
return <<'END';
10300	1032F	Old Italic
END
