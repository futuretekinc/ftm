
return <<'END';
1D300	1D35F	Tai Xuan Jing Symbols
END
