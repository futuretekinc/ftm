
return <<'END';
0C00	0C7F	Telugu
END
