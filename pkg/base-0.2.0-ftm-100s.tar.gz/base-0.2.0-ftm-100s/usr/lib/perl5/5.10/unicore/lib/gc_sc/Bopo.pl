
return <<'END';
3105	312C	Bopomofo
31A0	31B7	Bopomofo
END
