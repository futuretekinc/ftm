
return <<'END';
1D80	1DBF	Phonetic Extensions Supplement
END
