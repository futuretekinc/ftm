
return <<'END';
0C82	0C83	Kannada
0C85	0C8C	Kannada
0C8E	0C90	Kannada
0C92	0CA8	Kannada
0CAA	0CB3	Kannada
0CB5	0CB9	Kannada
0CBC	0CC4	Kannada
0CC6	0CC8	Kannada
0CCA	0CCD	Kannada
0CD5	0CD6	Kannada
0CDE		Kannada
0CE0	0CE3	Kannada
0CE6	0CEF	Kannada
0CF1	0CF2	Kannada
END
