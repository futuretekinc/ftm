
return <<'END';
0E80	0EFF	Lao
END
