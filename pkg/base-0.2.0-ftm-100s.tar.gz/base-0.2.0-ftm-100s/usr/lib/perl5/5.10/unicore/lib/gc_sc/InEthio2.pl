
return <<'END';
2D80	2DDF	Ethiopic Extended
END
