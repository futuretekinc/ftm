
return <<'END';
2E80	2E99	Radical
2E9B	2EF3	Radical
2F00	2FD5	Radical
END
