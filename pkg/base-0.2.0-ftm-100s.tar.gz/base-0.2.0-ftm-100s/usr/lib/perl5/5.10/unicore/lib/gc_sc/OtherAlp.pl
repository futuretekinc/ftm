
return <<'END';
0345		Other_Alphabetic
05B0	05BD	Other_Alphabetic
05BF		Other_Alphabetic
05C1	05C2	Other_Alphabetic
05C4	05C5	Other_Alphabetic
05C7		Other_Alphabetic
0610	0615	Other_Alphabetic
064B	0657	Other_Alphabetic
0659	065E	Other_Alphabetic
0670		Other_Alphabetic
06D6	06DC	Other_Alphabetic
06E1	06E4	Other_Alphabetic
06E7	06E8	Other_Alphabetic
06ED		Other_Alphabetic
0711		Other_Alphabetic
0730	073F	Other_Alphabetic
07A6	07B0	Other_Alphabetic
0901	0903	Other_Alphabetic
093E	094C	Other_Alphabetic
0962	0963	Other_Alphabetic
0981	0983	Other_Alphabetic
09BE	09C4	Other_Alphabetic
09C7	09C8	Other_Alphabetic
09CB	09CC	Other_Alphabetic
09D7		Other_Alphabetic
09E2	09E3	Other_Alphabetic
0A01	0A03	Other_Alphabetic
0A3E	0A42	Other_Alphabetic
0A47	0A48	Other_Alphabetic
0A4B	0A4C	Other_Alphabetic
0A70	0A71	Other_Alphabetic
0A81	0A83	Other_Alphabetic
0ABE	0AC5	Other_Alphabetic
0AC7	0AC9	Other_Alphabetic
0ACB	0ACC	Other_Alphabetic
0AE2	0AE3	Other_Alphabetic
0B01	0B03	Other_Alphabetic
0B3E	0B43	Other_Alphabetic
0B47	0B48	Other_Alphabetic
0B4B	0B4C	Other_Alphabetic
0B56	0B57	Other_Alphabetic
0B82		Other_Alphabetic
0BBE	0BC2	Other_Alphabetic
0BC6	0BC8	Other_Alphabetic
0BCA	0BCC	Other_Alphabetic
0BD7		Other_Alphabetic
0C01	0C03	Other_Alphabetic
0C3E	0C44	Other_Alphabetic
0C46	0C48	Other_Alphabetic
0C4A	0C4C	Other_Alphabetic
0C55	0C56	Other_Alphabetic
0C82	0C83	Other_Alphabetic
0CBE	0CC4	Other_Alphabetic
0CC6	0CC8	Other_Alphabetic
0CCA	0CCC	Other_Alphabetic
0CD5	0CD6	Other_Alphabetic
0CE2	0CE3	Other_Alphabetic
0D02	0D03	Other_Alphabetic
0D3E	0D43	Other_Alphabetic
0D46	0D48	Other_Alphabetic
0D4A	0D4C	Other_Alphabetic
0D57		Other_Alphabetic
0D82	0D83	Other_Alphabetic
0DCF	0DD4	Other_Alphabetic
0DD6		Other_Alphabetic
0DD8	0DDF	Other_Alphabetic
0DF2	0DF3	Other_Alphabetic
0E31		Other_Alphabetic
0E34	0E3A	Other_Alphabetic
0E4D		Other_Alphabetic
0EB1		Other_Alphabetic
0EB4	0EB9	Other_Alphabetic
0EBB	0EBC	Other_Alphabetic
0ECD		Other_Alphabetic
0F71	0F81	Other_Alphabetic
0F90	0F97	Other_Alphabetic
0F99	0FBC	Other_Alphabetic
102C	1032	Other_Alphabetic
1036		Other_Alphabetic
1038		Other_Alphabetic
1056	1059	Other_Alphabetic
135F		Other_Alphabetic
1712	1713	Other_Alphabetic
1732	1733	Other_Alphabetic
1752	1753	Other_Alphabetic
1772	1773	Other_Alphabetic
17B6	17C8	Other_Alphabetic
18A9		Other_Alphabetic
1920	192B	Other_Alphabetic
1930	1938	Other_Alphabetic
19B0	19C0	Other_Alphabetic
19C8	19C9	Other_Alphabetic
1A17	1A1B	Other_Alphabetic
1B00	1B04	Other_Alphabetic
1B35	1B43	Other_Alphabetic
24B6	24E9	Other_Alphabetic
A823	A827	Other_Alphabetic
FB1E		Other_Alphabetic
10A01	10A03	Other_Alphabetic
10A05	10A06	Other_Alphabetic
10A0C	10A0F	Other_Alphabetic
END
