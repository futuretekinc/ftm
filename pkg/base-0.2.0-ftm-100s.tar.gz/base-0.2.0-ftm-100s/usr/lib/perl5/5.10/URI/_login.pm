package URI::_login;

require URI::_server;
require URI::_userpass;
@ISA = qw(URI::_server URI::_userpass);


1;
