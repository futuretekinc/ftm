use CGI;

$VERSION = '1.00';

1;

__END__

