#define U_BOOT_DATE "Jan 08 2016"
#define U_BOOT_TIME "18:05:08"
