#define U_BOOT_DATE "Jan 07 2016"
#define U_BOOT_TIME "13:23:52"
