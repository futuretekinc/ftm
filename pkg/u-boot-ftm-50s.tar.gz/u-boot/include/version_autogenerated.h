#define U_BOOT_VERSION "U-Boot 2010.03-lsp-3.2.5-dirty-svn30"
