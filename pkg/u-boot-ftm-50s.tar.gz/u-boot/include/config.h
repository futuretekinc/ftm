/* Automatically generated - do not edit */
#define CONFIG_MK_spear320 1
#define CONFIG_MK_ftm2 1
#define CONFIG_BOARDDIR board/spear/spear320_ftm2
#include <config_defaults.h>
#include <configs/spear3xx_ftm2.h>
#include <asm/config.h>
