/* Automatically generated - do not edit */
#define CONFIG_MK_spear320 1
#define CONFIG_MK_ftm 1
#define CONFIG_BOARDDIR board/spear/spear320_ftm
#include <config_defaults.h>
#include <configs/spear3xx_ftm.h>
#include <asm/config.h>
