
- FTM-100S model
System defines $MODEL as "FTM-100S".  Use it for model detection.

- FTM-50S model
Detected from ```uname -sr```
