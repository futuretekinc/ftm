define({
  'titles': {
    'home': '홈',
    'register': '등록',
    'setting': '설정',
    'about': 'about',
    'signout': '로그아웃',
    'signin': '로그인'
  },
  'commands': {
    'close': '닫기',
    'save': '저장',
    'cancel': '취소'
  }
});