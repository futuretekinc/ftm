#!/bin/bash
# restore file of integrity

cd /mnt/ramdisk/do/
tar -zxf ssl.tar.gz
