#!/bin/sh
# Do vpn  masquerading
#route add -net 192.168.100.1 netmask 255.255.255.255 dev tun0

omnifilter -F
omnifilter -t nat -A POSTROUTING -o tun0 -j MASQUERADE
omnifilter -t nat -A POSTROUTING -o usb0 -j MASQUERADE
