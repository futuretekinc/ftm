# To build the sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).