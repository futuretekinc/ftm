// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef __cplusplus
#error NO CHEATING!
#endif
#include "../codefirst_ut/codefirst_ut.c"

