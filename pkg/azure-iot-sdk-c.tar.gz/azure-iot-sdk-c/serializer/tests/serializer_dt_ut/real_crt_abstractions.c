// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define COMPILING_REAL_CRT_ABSTRACTIONS_C

#define GBALLOC_H

#include "real_crt_abstractions.h"
#include "crt_abstractions.c"
