#ifndef __ASM_ARM_STRING_H
#define __ASM_ARM_STRING_H

#endif
