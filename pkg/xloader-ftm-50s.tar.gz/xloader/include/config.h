
/* Automatically generated - do not edit */
#include <configs/spear320_hmi.h>
#include <asm/config.h>
