#include <stdio.h> /* Standard input/output definitions */
#include <string.h> /* String function definitions */
#include <unistd.h> /* UNIX standard function definitions */
#include <fcntl.h> /* File control definitions */
#include <errno.h> /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include "qdecoder.h"


int IOT_DDNS(qentry_t *pReq)
{
		// Parse queries.
		qentry_t *req = qcgireq_parse(NULL, 0);

		// Get values
		char *value = (char *)req->getstr(req, "cmd", false);
		FILE *fp;
		char resBuf[256];

		if (strcmp(value, "state") == 0)
		{
				qcgires_setcontenttype(req, "text/xml");
				printf("<DDNS>\n");
				fp = popen("cat /etc/ddns/nsupdate.script | awk -f /www/cgi-bin/ddns.awk", "r");
				while(fgets(resBuf, sizeof(resBuf), fp) != 0)
				{
						char szDNS[64];
						char szDomain[64];
						char szIP[64];

						if (3 == sscanf(resBuf, "%s %s %s", szDNS, szDomain, szIP))
						{
								printf("<DNS>%s</DNS>\n", szDNS);
								printf("<DOMAIN>%s</DOMAIN>\n", szDomain);
								printf("<IP>%s</IP>\n", szIP);
						}
				}
				printf("</DDNS>");
				pclose(fp);
				return 0;

		} else if (strcmp(value, "set") == 0) {
				char *lpszDNS       = pReq->getstr(pReq, "dns", false);
				char *lpszDomain 	= pReq->getstr(pReq, "domain", false);
				char *lpszIP    	= pReq->getstr(pReq, "ip", false);
				char *lpszIMSI    	= pReq->getstr(pReq, "imsi", false);

				if ((lpszDNS == NULL) || 
					(lpszDomain == NULL) ||
					(lpszIP == NULL) ||
					(lpszIMSI == NULL))
				{
						qcgires_setcontenttype(pReq, "text/xml");
						printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
						printf("<DHCP_CONFIG>\n");
						printf("<RET>ERROR</RET>\n");
						printf("<MSG>Invalid Parameter!</MSG>\n");
						printf("</DHCP_CONFIG>\n");
				}

				FILE *fp = fopen("/tmp/nsupdate.script", "w");
				if (fp == NULL)
				{
						qcgires_setcontenttype(pReq, "text/xml");
						printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
						printf("<DHCP_CONFIG>\n");
						printf("<RET>SYSTEM_ERROR</RET>\n");
						printf("<MSG>Can't create file\n[/tmp/udhcpd.conf]</MSG>\n");
						printf("</DHCP_CONFIG>\n");
						return  -1;
				}

				fprintf(fp, "server %s\n", lpszDNS);
				fprintf(fp, "debug yes\n");
				fprintf(fp, "zone %s.\n", lpszDomain);
				fprintf(fp, "update delete %s.%s\n", lpszIMSI, lpszDomain);
				fprintf(fp, "update add %s.%s 60 A %s\n", lpszIMSI, lpszDomain, lpszIP);
				fprintf(fp, "show\n");
				fprintf(fp, "send\n");
				fclose(fp);

				fp = popen("cp -f /tmp/nsupdate.script /etc/ddns/nsupdate.script", "r");
				pclose(fp);

				char resolv_command[100];
				sprintf(resolv_command, "echo 'nameserver %s' > /etc/resolv.conf", lpszDNS);

				fp = popen(resolv_command, "r");
				pclose(fp);


				fp = popen("ls /etc/ddns/*.key", "r");
				char szKey[64];

				while(fgets(resBuf, sizeof(resBuf), fp) != 0)
				{		
						sscanf(resBuf, "%s", szKey);
				}
				pclose(fp);

				char command[100];
                sprintf(command, "nsupdate -k %s -v /etc/ddns/nsupdate.script", szKey);
				fp = popen(command, "r");
				pclose(fp);
				
				
				qcgires_setcontenttype(pReq, "text/xml");
				printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
				printf("<DDNS_CONFIG>\n");
				printf("<RET>OK</RET>\n");
				printf("</DDNS_CONFIG>\n");
		}

		return 0;
		
}
