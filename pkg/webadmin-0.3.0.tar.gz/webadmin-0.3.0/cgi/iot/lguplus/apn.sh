chat TIMEOUT 1 "" "AT+CGDCONT=1,IP,$1,0.0.0.0,0,0" "OK" > /dev/ttyS1
