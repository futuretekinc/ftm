#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <xml.h>
#include "qdecoder.h"

int FTMC_LTE(qentry_t *pReq)
{

	int		nRet = -1;
	FILE *pFP = NULL;
	char *pCmd = pReq->getstr(pReq, "cmd", false);

	qcgires_setcontenttype(pReq, "application/json");
	printf("{\n");
	if (strcmp(pCmd, "get") == 0)
	{
		char	szBuf[1024];
		pFP = popen("/www/cgi-bin/scripts/lte.sh get", "r");
		if (pFP != NULL)
		{
			printf("\t\"lte\" : ");
			while(fgets(szBuf, sizeof(szBuf), pFP) != 0)
			{
				printf(szBuf);
			}
			printf(",\n");
		}

		nRet = 0;
	}
	else if (strcmp(pCmd, "set") == 0)
	{
		char *pInterval;
		char *pMaxLoop;
		char *pAPN;

		pFP = fopen("/tmp/_lte", "w");
		if (pFP == NULL)
		{
			goto error;
		}

		pInterval = pReq->getstr(pReq, "interval", false);
		pMaxLoop = pReq->getstr(pReq, "maxLoop", false);
		pAPN = pReq->getstr(pReq, "apn", false);

		fprintf(pFP, "config lte\n");
		fprintf(pFP, "\toption\tinterval\t%s\n", pInterval);
		fprintf(pFP, "\toption\tmaxLoop\t%s\n", pMaxLoop);
		fprintf(pFP, "\toption\tapn\t%s\n", pAPN);
		fclose(pFP);

		pFP = popen("/bin/cp -f /tmp/_lte /etc/config/lte;sync;rm /tmp/_lte;sync", "r");
		pclose(pFP);
		pFP = NULL;

		nRet = 0;
	}	

error:
	if (pFP != NULL)
	{
		fclose(pFP);	
	}

	if (nRet == 0)
	{
		printf("\t\"result\" : \"success\"\n");
	}
	else
	{
		printf("\t\"result\" : \"error\"\n");
	}
	printf("}\n");

	return	0;
}
