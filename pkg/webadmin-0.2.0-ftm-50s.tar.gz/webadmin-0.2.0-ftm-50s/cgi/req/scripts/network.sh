#!/bin/sh

get_if_info()
{
	ifconfig $1 | awk 'BEGIN{mac="";ipaddr="";netmask=""}{ if ($4 ~ /HWaddr/) {mac=$5} else if ($1 ~ /^inet$/) {split($2, tmp, ":"); ipaddr=tmp[2]; split($4, tmp, ":");netmask=tmp[2]} }END{printf("%s %s %s", mac,ipaddr,netmask)}'
}

get_mac()
{
	ifconfig $1 | awk 'BEGIN{mac=""}{ if ($4 ~ /HWaddr/) {mac=$5}}END{printf("%s", mac)}'
}

get_ip()
{
	ifconfig $1 | awk 'BEGIN{ipaddr=""}{ if ($1 ~ /^inet$/) {split($2, tmp, ":"); ipaddr=tmp[2]} }END{printf("%s", ipaddr)}'
}

get_netmask()
{
	ifconfig $1 | awk 'BEGIN{netmask=""}{ if ($1 ~ /^inet$/) {split($4, tmp, ":");netmask=tmp[2]} }END{printf("%s", netmask)}'
}

get_gateway()
{
	route | awk '{ if ($1 ~ /default/) print $2 }'
}

get_brif()
{
	brctl show | awk -v bridge=$1 'BEGIN{found=0}{if(NF == 4 && $1 ~ bridge){found=1; print $4} else if (NF == 1 && found == 1){print $1} else {found=0}}END{}'
}

