#!/bin/sh /etc/rc.common

IFACE_INFO=
WAN_INFO=
LAN_INFO=
DNS_INFO=

read_interface()
{
	local   ifname
	local   type
	local   proto
	local   ipaddr
	local   netmask
	local   gateway
	local   active

	config_get ifname $1 ifname
	[ -n "${ifname}" ] && [ "${ifname}" != "lo" ] || return

	config_get type $1 type
	[ -n "${type}" ] || return

	case "${type}" in
	"wan")
		config_get active $i active
		[ -n "${active}" ] || return
		;;

	"lan")
		config_get proto $1 proto
		[ -n "${proto}" ] || return
		;;

	"wanif")
		config_get proto $1 proto
		[ -n "${proto}" ] || return

		config_get gateway $1 gateway

		append IFACE_INFO "<iface>"
		append IFACE_INFO "<ifname>${ifname}</ifname>"
		append IFACE_INFO "<iftype>wan</iftype>"
		append IFACE_INFO "</iface>"
		;;

	"lanif")
		append IFACE_INFO "<iface>"
		append IFACE_INFO "<ifname>${ifname}</ifname>"
		append IFACE_INFO "<iftype>lan</iftype>"
		append IFACE_INFO "</iface>"
		;;
	*)
		return
	esac

	case "${proto}" in
	"static")
		local   INFO

		config_get ipaddr $1 ipaddr
		[ -n "${ipaddr}" ] || return

		config_get netmask $1 netmask
		[ -n "${netmask}" ] || return

		if [ "${type}" = "wanif" ]; then
            append WAN_INFO "<eth>"                
			append WAN_INFO "<ifname>${ifname}</ifname>"
			append WAN_INFO "<proto>${proto}</proto>"   
			append WAN_INFO "<ipaddr>${ipaddr}</ipaddr>"
			append wAN_INFO "<netmask>${ipaddr}</netmask>"
			append WAN_INFO "<gateway>${gateway}</gateway>"
			append WAN_INFO "</eth>"                       
		else                                                   
			append LAN_INFO "<eth>"                        
			append LAN_INFO "<ifname>${ifname}</ifname>"   
			append LAN_INFO "<proto>${proto}</proto>"      
			append LAN_INFO "<ipaddr>${ipaddr}</ipaddr>"   
			append LAN_INFO "<netmask>${ipaddr}</netmask>" 
			append LAN_INFO "</eth>"                       
		fi                                                     
		;;                                                     

	"dhcp")                                                        
		local   INFO                                           

		if [ "${type}" = "wanif" ]; then                      
			append WAN_INFO "<eth>"                       
			append WAN_INFO "<ifname>${ifname}</ifname>"  
			append WAN_INFO "<proto>${proto}</proto>"      
			append WAN_INFO "</eth>"                      
		else                                                  
			append LAN_INFO "<eth>"                     
			append LAN_INFO "<ifname>${ifname}</ifname>"
			append LAN_INFO "<proto>${proto}</proto>"   
			append LAN_INFO "</eth>"                    
		fi                                                    
		;;                                                  
	esac                                                          

}                                                                      

read_dns()                                                          
{
	local	host
	local	name

	config_get host $1 host
	[ -n "${host}" ] || return
	
	config_get name $1 name 
	[ -n "${name}" ] || name="${host}"

	append DNS_INFO "<dns><name>${name}</name><host>${host}</host></dns>"
}                                                                   

start()                                                               
{                                                                   
	config_load network                                           

	config_foreach  read_interface interface                    
    config_foreach  read_dns dns                             

	echo "<?xml version='1.0' encoding='ISO-8859-1'?>"
	echo "<STATUS_NETWORK>"
	[ -n "${IFACE_INFO}" ] && echo "${IFACE_INFO}"      
	[ -n "${WAN_INFO}" ] && echo "${WAN_INFO}"         
	[ -n "${LAN_INFO}" ] && echo "${LAN_INFO}"            
	[ -n "${DNS_INFO}" ] && echo "${DNS_INFO}"            
	echo "</STATUS_NETWORK>"
}  
