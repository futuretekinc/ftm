#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <xml.h>
#include "qdecoder.h"

int FTMC_Network(qentry_t *pReq)
{

	int		nRet = -1;
	FILE *pFP = NULL;
	char *pCmd = pReq->getstr(pReq, "cmd", false);

	qcgires_setcontenttype(pReq, "application/json");
	printf("{\n");
	if (strcmp(pCmd, "get") == 0)
	{
		char	szBuf[1024];
		pFP = popen("/www/cgi-bin/scripts/network_status.sh start", "r");
		if (pFP != NULL)
		{
			printf("\t\"network\" : ");
			while(fgets(szBuf, sizeof(szBuf), pFP) != 0)
			{
				printf(szBuf);
			}
			printf(",\n");
		}

		nRet = 0;
	}
	else if (strcmp(pCmd, "set") == 0)
	{
		char *pType;
		char *pName;
		char *pProto;
		char *pIPAddr;
		char *pNetmask;
		char *pGateway;
		char *pPort;
		int		i, nPort;

		pFP = fopen("/tmp/_network.usr", "w");
		if (pFP == NULL)
		{
			goto error;
		}

		for(i = 0 ; ; i++)
		{
			pType = pReq->getstrf(pReq, false, "type%d", i);
			if (pType == NULL)
			{
				break;
			}

			fprintf(pFP, "config interface\n");
			fprintf(pFP, "\toption\ttype\t%s\n", pType);

			pName = pReq->getstrf(pReq, false, "name%d", i);
			if (pName == NULL)
			{
				pName = pType;	
			}

			fprintf(pFP, "\toption\tname\t%s\n", pName);

			pProto = pReq->getstrf(pReq, false, "proto%d", i);
			if (pProto == NULL)
			{
				goto error;	
			}

			fprintf(pFP, "\toption\tproto\t%s\n", pProto);

			if (strcasecmp(pProto, "static") == 0)
			{
				pIPAddr = pReq->getstrf(pReq, false, "ip%d", i);
				if (pIPAddr == NULL)
				{
					goto error;	
				}

				fprintf(pFP, "\toption\tipaddr\t%s\n", pIPAddr);

				pNetmask = pReq->getstrf(pReq, false, "netmask%d", i);
				if (pNetmask == NULL)
				{
					goto error;	
				}

				fprintf(pFP, "\toption\tnetmask\t%s\n", pNetmask);

				if (strcasecmp(pType, "wan") == 0)
				{
					pGateway = pReq->getstrf(pReq, false, "gateway%d", i);
					if (pGateway == NULL)
					{
						goto error;	
					}

					fprintf(pFP, "\toption\tgateway\t%s\n", pGateway);
				}
			}
	
			pPort = pReq->getstrf(pReq, false, "port%d", i);
			if (pPort != NULL)
			{
				fprintf(pFP, "\toption\tport\t%s\n", pPort);	
			}
			else
			{
				for(nPort = 0 ; nPort < 10 ; nPort++)
				{
					pPort = pReq->getstrf(pReq, false, "port%d-%d", i, nPort);
					if (pPort != NULL)
					{
						fprintf(pFP, "\toption\tport%d\t%s\n", nPort, pPort);	
					}
				}
			}
			fprintf(pFP,"\n");
		}

		pFP = popen("/bin/cp -f /tmp/_network.usr /etc/config/network.usr;sync;rm /tmp/_network.usr;sync", "r");

		nRet = 0;
	}	

error:
	if (pFP != NULL)
	{
		fclose(pFP);	
	}

	qcgires_setcontenttype(pReq, "application/json");
	if (nRet == 0)
	{
		printf("\t\"result\" : \"success\"\n");
	}
	else
	{
		printf("\t\"result\" : \"error\"\n");
	}
	printf("}\n");

	return	0;
}
