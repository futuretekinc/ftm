#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <xml.h>
#include "qdecoder.h"

int FTMC_Network(qentry_t *pReq)
{

	FILE *pFP = NULL;
	char *lpszCmd = pReq->getstr(pReq, "cmd", false);

	if (strcmp(lpszCmd, "status") == 0)
	{
		char	szBuf[1024];
		pFP = popen("/www/cgi-bin/status_network.sh", "r");
		if (pFP != NULL)
		{
			qcgires_setcontenttype(pReq, "text/xml");
			printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
			printf("<STATUS_NETWORK>\n");
			while(fgets(szBuf, sizeof(szBuf), pFP) != 0)
			{
				int		nIndex;
				char	szType[64];
				char	szIFName[64];
				char	szIPAddr[64];
				char	szNetmask[64];
				char	szGateway[64];
				printf("<CMT>%s</CMT>\n", szBuf);
				if (1 == sscanf(szBuf, "%s", szType))
				{
					if (strcmp(szType, "eth") == 0)
					{
						if (6 == sscanf(szBuf, "%s %d %s %s %s %s", szType, &nIndex, szIFName, szIPAddr, szNetmask, szGateway))
						{
							printf("<ETH>\n");
							printf("<INDEX>%d</INDEX>\n", nIndex);	
							printf("<IFNAME>%s</IFNAME>\n", szIFName);	
							printf("<IPADDR>%s</IPADDR>\n", szIPAddr);	
							printf("<NETMASK>%s</NETMASK>\n", szNetmask);	
							printf("<MACADDR>%s</MACADDR>\n", szGateway);	
							printf("</ETH>\n");
						}
					}
					else if (strcmp(szType, "p2p") == 0)
					{
						if (6 == sscanf(szBuf, "%s %d %s %s %s %s", szType, &nIndex, szIFName, szIPAddr, szNetmask, szGateway))
						{
							printf("<PTP>\n");
							printf("<INDEX>%d</INDEX>\n", nIndex);	
							printf("<IFNAME>%s</IFNAME>\n", szIFName);	
							printf("<IPADDR>%s</IPADDR>\n", szIPAddr);	
							printf("<NETMASK>%s</NETMASK>\n", szNetmask);	
							printf("<PEER>%s</PEER>\n", szGateway);	
							printf("</PTP>\n");
						}
					}
					else if (strcmp(szType, "dns") == 0)
					{
						if (4 == sscanf(szBuf, "%s %d %s %s", szType, &nIndex, szIFName, szIPAddr))
						{
							printf("<DNS>\n");
							printf("<INDEX>%d</INDEX>\n", nIndex);	
							printf("<NAME>%s</NAME>\n", szIFName);	
							printf("<IPADDR>%s</IPADDR>\n", szIPAddr);	
							printf("</DNS>\n");
						}
					}
				}
			}
			printf("</STATUS_NETWORK>\n");
			pclose(pFP);
		}
	}
	else if (strcmp(lpszCmd, "set") == 0)
	{
		char *lpszProto;
		char *lpszIPAddr;
		char *lpszNetmask;

		pFP = fopen("/tmp/_network", "w");
		if (pFP == NULL)
		{
			goto error;
		}

		fprintf(pFP, "config interface\n");
		fprintf(pFP, "\toption ifname\tlo\n");
		fprintf(pFP, "\toption type\tloopback\n");
		fprintf(pFP, "\n");

		fprintf(pFP, "config interface\n");
		fprintf(pFP, "\toption ifname\twan\n");
		fprintf(pFP, "\toption type\twan\n");
		fprintf(pFP, "\toption active\teth1\n");
		fprintf(pFP, "\n");

		fprintf(pFP, "config interface\n");
		fprintf(pFP, "\toption ifname\teth1\n");
		fprintf(pFP, "\toption type\twanif\n");
		fprintf(pFP, "\toption proto\tdhcp\n");
		fprintf(pFP, "\n");

		fprintf(pFP, "config interface\n");
		fprintf(pFP, "\toption ifname\tlan\n");
		fprintf(pFP, "\toption type\tlan\n");
		fprintf(pFP, "\toption proto\tstatic\n");
		lpszIPAddr = pReq->getstr(pReq, "lan_ipaddr", false);
		lpszNetmask= pReq->getstr(pReq, "lan_netmask", false);
		if ((lpszIPAddr == NULL) || (lpszNetmask == NULL))
		{
			goto error;	
		}

		fprintf(pFP, "\toption ipaddr\t%s\n", lpszIPAddr);
		fprintf(pFP, "\toption netmask\t%s\n", lpszNetmask);
		fprintf(pFP, "\n");
	
		int	i = 0;
		for( i  0 ;  ; i++)
		{
			char *lpszIFName = pReq->getstrf(pReq, false, "lan_if%d", i);
			if (lpszIFName == NULL)
			{
				break;
			}

			fprintf(pFP, "config interface\n");
			fprintf(pFP, "\toption ifname\t%s\n", lpszIFName);
			fprintf(pFP, "\toption type\tlanif\n");
			fprintf(pFP, "\n");
		}

		if (i == 0)
		{
			fprintf(pFP, "config interface\n");
			fprintf(pFP, "\toption ifname\teth0\n");
			fprintf(pFP, "\toption type\tlanif\n");
			fprintf(pFP, "\n");
		}
		
		for(i = 0 ; ; i++)
		{
			char *lpszDNS = pReq->getstrf(pReq, false, "dns%d", i);
			if (lpszDNS == NULL)
			{
				break;
			}
			fprintf(pFP, "config dns\n");
			fprintf(pFP, "\toption\thost\t%s\n", lpszDNS);
			fprintf(pFP, "\n");
		}
		fclose(pFP);

		pFP = popen("/bin/cp -f /tmp/_network /etc/config/network;sync;rm /tmp/_network;sync", "r");
		pclose(pFP);

		qcgires_setcontenttype(pReq, "text/xml");
		printf("<?xml version='1.0' encoding='ISO-8859-1'?>\n");
		printf("<CONFIG_NETWORK>\n");
		printf("<RET>OK</RET>\n");
		printf("</CONFIG_NETWORK>\n");		
	}	
	else
	{
		goto error;
	}

	return	0;

error:
	if (pFP != NULL)
	{
		fclose(pFP);	
	}

	printf("<RET>ERROR</RET>\n");

	return	-1;
}
