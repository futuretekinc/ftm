/**
 * Created by kindmong on 2015-11-05.
 */
function init() {
    $.li18n.currentLocale = 'kr';
    document.getElementById("menu_dashboard").innerHTML = _t('dashboard');
    document.getElementById("menu_sensors").innerHTML = _t('sensors');
    document.getElementById("menu_clouds").innerHTML = _t('clouds');
    document.getElementById("menu_network").innerHTML = _t('network');
    document.getElementById("menu_system").innerHTML = _t('system');
	document.getElementById("modify_btn").innerHTML = _t('modify');
}

$(document).ready(function(){
    init();
    initVPN();
});

function initVPN() {
    $.ajax({
        type:"get",
        url:"/cgi-bin/sslvpn?cmd=state",
        dataType:"xml",
        success : function(xml) {
            // 통신이 성공적으로 이루어졌을 때 이 함수를 타게 된다.
            // TODO
            $(xml).find("SSLVPN").each(function(){
                var remote_tf = document.getElementById("remote");
				var port_tf = document.getElementById("port");
				var auth_retry_tf = document.getElementById("auth_retry");
				var connect_retry_tf = document.getElementById("connect_retry");
				var connect_retry_max_tf = document.getElementById("connect_retry_max");
				var id_tf = document.getElementById("id");
				var password_tf = document.getElementById("password");

				remote_tf.value = $(this).find("REMOTE").text();
				port_tf.value = $(this).find("REMOTE_PORT").text();
				auth_retry_tf.value = $(this).find("AUTH_RETRY").text();
				connect_retry_tf.value = $(this).find("CONNECT_RETRY").text();
				connect_retry_max_tf.value = $(this).find("CONNECT_RETRY_MAX").text();
				id_tf.value = $(this).find("ID").text();
				password_tf.value = $(this).find("PW").text();
            });
        },
        error : function(xhr, status, error) {
			//alert("에러발생");
			window.location.href="/";
        }
    });
}

function setVPN()
{
	if(typeof window.ActiveXObject != 'undefined') {
		xmlhttp = (new ActiveXObject("Microsoft.XMLHTTP"));
	} else {
		xmlhttp = (new XMLHttpRequest());
	}
		
	var data = "/cgi-bin/sslvpn?cmd=set"

	var remote_tf = document.getElementById("remote");
	var port_tf = document.getElementById("port");
	var auth_retry_tf = document.getElementById("auth_retry");
	var connect_retry_tf = document.getElementById("connect_retry");
	var connect_retry_max_tf = document.getElementById("connect_retry_max");
	var id_tf = document.getElementById("id");
	var password_tf = document.getElementById("password");

	data += "&remote=" + remote_tf.value;
	data += "&remote_port=" + port_tf.value;
	data += "&auth_retry=" + auth_retry_tf.value;
	data += "&connect_retry=" + connect_retry_tf.value;
	data += "&connect_retry_max=" + connect_retry_max_tf.value;
	data += "&id=" + id_tf.value;
	data += "&pw=" + password_tf.value;

	xmlhttp.open( "POST", data, true );
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=euc-kr");
	xmlhttp.onreadystatechange = function()
	{
		if( (xmlhttp.readyState == 4) && (xmlhttp.status == 200) )
		{
			try
			{
				result = xmlhttp.responseXML.documentElement.getElementsByTagName("RET")[0];
				if (result.firstChild.nodeValue == 'OK') {
					alert("접속을 다시 시도합니다.");
				} else {
					alert("VPN : ERROR");
				}
			}
			catch(e)
			{

			}
		}
	}
	xmlhttp.send();
}