/**
 * Created by kindmong on 2015-11-05.
 */
$(document).ready(function(){
    init();
});

function init() {
	alert("WIFI 미탑제");
	window.location.href = "../../pages/network.html";
}